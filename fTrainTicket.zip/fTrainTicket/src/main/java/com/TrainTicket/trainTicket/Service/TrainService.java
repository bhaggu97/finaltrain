package com.TrainTicket.trainTicket.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TrainTicket.trainTicket.model.Train;
import com.TrainTicket.trainTicket.repository.Admin;

@Service
public class TrainService {

	private final Admin trainRepository;

	@Autowired
	public TrainService(Admin trainRepository) {

		this.trainRepository = trainRepository;

		Train train1 = new Train(4, "Gomti Express", "Lucknow", "Aligarh", 120.0);

		Train train2 = new Train(3, "Rajdhani Express", "Delhi", "Hyderabad", 765.0);

		Train train3 = new Train(2, "Pushpak Express", "Lucknow", "Mumbai", 850.0);

		Train train4 = new Train(1, "Bullet Express", "Mumbai", "Ahmadabad", 1200.0);

		List<Train> trains = new ArrayList<Train>();
		trains.add(train1);
		trains.add(train2);
		trains.add(train3);
		trains.add(train4);

		trainRepository.saveAll(trains);
	}

	public Optional<Train> getTrainByNumber(int trainNumber) {
		return trainRepository.findById(trainNumber);
	}

	public List<Train> getAllTrains() {
		return trainRepository.findAll();
	}

	

}
