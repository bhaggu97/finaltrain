package com.TrainTicket.trainTicket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.TrainTicket.trainTicket.model.Train;

@Repository
public interface Admin extends JpaRepository<Train, Integer> {

}
