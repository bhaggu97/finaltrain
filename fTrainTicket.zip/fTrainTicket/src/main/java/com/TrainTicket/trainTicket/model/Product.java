package com.TrainTicket.trainTicket.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int Train_Number;
    
	private String Train_Name;
	private String Source;
	private String Destination;
	private int Fare ;

	public int getTrain_Number() {
		return Train_Number;
	}

	public void setTrain_Number(int Train_Number) {
		this.Train_Number = Train_Number;
	}

	public String getTrain_Name() {
		return Train_Name;
	}

	public void setTrain_Name(String Train_Name) {
		this.Train_Name = Train_Name;
	}

	public String getSource() {
		return Source;
	}

	public void setSource(String Source) {
		this.Source = Source;
	}

	public String getDestination() {
		return Destination;
	}

	public void setDestination(String Destination) {
		this.Destination = Destination;
	}

	public int getFare() {
		return Fare;
	}

	public void setFare(int Fare) {
		this.Fare = Fare;
	}

}