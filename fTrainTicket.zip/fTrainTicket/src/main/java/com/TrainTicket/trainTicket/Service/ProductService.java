package com.TrainTicket.trainTicket.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TrainTicket.trainTicket.model.Product;
import com.TrainTicket.trainTicket.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;

	public void saveProduct(Product product) {
		productRepository.save(product);
	}

	public void editProduct(Product product) {
		productRepository.save(product);
	}

	public Optional<Product> getProduct(int Train_Number) {
		return productRepository.findById(Train_Number);
	}

	public List<Product> getAllProduct() {
		return productRepository.findAll();
	}

	public void deleteProduct(int Train_Number) {
		productRepository.deleteById(Train_Number);
	}

}